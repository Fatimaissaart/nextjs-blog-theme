# Random Quotes Machine

This is an app that provides quotes randomly based on a list of quotes of my choice. Each time a new quote appears, a new color for the background is used (selected randomly as well).

The idea for this project comes from the [freeCodeCamp][fcc] curriculum.

In fact this is the same design that the example provided, but I just experimented using Firestore database to use my own quotes and colors.


So this [project][deploy] is deployed with Netlify.

[fcc]: https://www.freecodecamp.org/
[deploy]: https://randomq.netlify.app/