
type UserCred = { uid: string };

export { UserCred }