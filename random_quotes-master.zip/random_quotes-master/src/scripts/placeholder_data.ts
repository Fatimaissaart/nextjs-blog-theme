// DATA HARD CODED: is there a better way ?
const placeholderData = {
    quotes: [
        {
            "quote": "It does not matter how slowly you go as long as you do not stop.",
            "author": "Confucius"
        },
        {
            "quote": "Life is 10% what happens to me and 90% of how I react to it.",
            "author": "Charles Swindoll"
        },
        {
            "quote": "Start where you are. Use what you have. Do what you can.",
            "author": "Arthur Ashe"
        },
        {
            "quote": "Remember no one can make you feel inferior without your consent.",
            "author": "Eleanor Roosevelt"
        },
        {
            "quote": "Life is what happens to you while you’re busy making other plans.",
            "author": "John Lennon"
        }
    ],
    colors: ["#ff6666", "#006600", "#3399ff", "#d966ff", "#ff8000"]
}

export default placeholderData